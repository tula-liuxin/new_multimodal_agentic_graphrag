# -*- coding: utf-8 -*-
from __future__ import annotations
import json, re
from pathlib import Path
from collections import defaultdict, Counter
from typing import Dict, List
from .utils import load_cfg, get_logger, ensure_dir, norm_win_abs, tqdm_wrap

def _ngrams(s: str, n: int = 2) -> List[str]:
    s = re.sub(r"\s+", "", s)
    return [s[i:i+n] for i in range(max(0, len(s)-n+1))]

def run_charindex(cfg=None, logger=None, n:int=2, max_docs:int=50000, max_per_token:int=2000):
    cfg = cfg or load_cfg()
    logger = logger or get_logger()
    data_dir = Path(cfg["data_dir"])
    chunks = data_dir / "chunks.jsonl"
    if not chunks.exists():
        logger.warning("未发现 %s，跳过 charindex。", chunks)
        return

    inv = defaultdict(list)  # token -> [doc id,...]
    seen = set()
    cnt = Counter()
    with chunks.open("r", encoding="utf-8") as f:
        for i, line in enumerate(tqdm_wrap(f, desc="charindex")):
            if i >= max_docs:
                break
            try:
                obj = json.loads(line)
            except Exception:
                continue
            rid = obj.get("id") or obj.get("rid") or obj.get("path") or str(i)
            if rid in seen: 
                continue
            seen.add(rid)
            text = (obj.get("text") or "")[:800]  # 只取前 800 字粗建索引
            for tok in _ngrams(text, n=n):
                if len(inv[tok]) < max_per_token:
                    inv[tok].append(rid)
            cnt.update(_ngrams(text, n=n))

    ensure_dir(data_dir)
    with (data_dir / "char_index.json").open("w", encoding="utf-8") as f:
        json.dump(inv, f, ensure_ascii=False)
    with (data_dir / "char_stats.json").open("w", encoding="utf-8") as f:
        json.dump(cnt.most_common(50000), f, ensure_ascii=False, indent=2)
    logger.info("charindex 完成：docs=%d, tokens=%d", len(seen), len(inv))
