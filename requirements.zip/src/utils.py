# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sys, json, logging, hashlib, re
from pathlib import Path
from typing import Iterable, Iterator, Sequence, Tuple, Optional, Union, Dict, Any

try:
    import yaml  # type: ignore
except Exception:
    yaml = None

def load_cfg(path: Union[str, Path] = "C:\\MyNotion\\new_multimodal_agentic_graphrag\\config.yaml") -> Dict[str, Any]:
    proj_root = Path("C:\\MyNotion\\new_multimodal_agentic_graphrag").resolve()
    default = {
        "project_root": str(proj_root),
        "data_dir": str(proj_root / "data"),
        "input_dir": "C:\\MyNotion\\MyNotion20251007",
        "enable_ocr": False,
        "ocr_lang": "chi_sim+eng",
        "ocr_psm": 6,
        "ollama_base_url": "http://127.0.0.1:11434",
        "embed_model": "nomic-embed-text",
        "embed_batch": 128,
        "embed_concurrency": 2,
        "embed_num_thread": 8,
        "embed_keep_alive": "10m",
        "embed_timeout": 120,
        "image_model_name": "ViT-L-14",
        "image_pretrained": "laion2b_s32b_b82k",
        "image_batch": 64,
        "image_precision": "fp16",
        "image_workers": 6,
    }

    cfg_path = Path(path)
    if cfg_path.exists() and yaml is not None:
        try:
            with cfg_path.open("r", encoding="utf-8") as f:
                file_cfg = yaml.safe_load(f) or {}
            default.update(file_cfg)
        except Exception:
            pass

    for k in list(default.keys()):
        if k.upper() in os.environ:
            default[k] = os.environ[k.upper()]

    default["project_root"] = norm_win_abs(default["project_root"])
    default["data_dir"] = norm_win_abs(default["data_dir"])
    default["input_dir"] = norm_win_abs(default["input_dir"])
    return default

def get_logger(name: str = "mmgr", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.handlers:
        handler = logging.StreamHandler(stream=sys.stdout)
        fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
        handler.setFormatter(fmt)
        logger.addHandler(handler)
    return logger

def ensure_dir(p: Union[str, Path]) -> str:
    """mkdir -p，返回绝对 Windows 路径（去掉 \\?\ 前缀）。"""
    path = Path(p)
    path.mkdir(parents=True, exist_ok=True)
    return norm_win_abs(path)

def norm_win_abs(p: Union[str, Path]) -> str:
    try:
        s = str(Path(p).resolve())
    except Exception:
        s = str(Path(p).absolute())
    s = s.replace("/", "\\")
    if s.startswith("\\?\\"):
        s = s[4:]
    return s

def sha1(s: Union[str, bytes]) -> str:
    if isinstance(s, str):
        s = s.encode("utf-8", errors="ignore")
    return hashlib.sha1(s).hexdigest()

def walk_files(root: Union[str, Path],
               exts: Optional[Sequence[str]] = None) -> Iterator[str]:
    root = Path(root)
    if not root.exists():
        return
    exts_norm = None if exts is None else {e.lower() for e in exts}
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if exts_norm is not None and p.suffix.lower() not in exts_norm:
            continue
        yield norm_win_abs(p)

def tqdm_wrap(iterable: Iterable, **kwargs):
    try:
        from tqdm import tqdm  # type: ignore
        default = dict(ncols=80)
        default.update(kwargs)
        return tqdm(iterable, **default)
    except Exception:
        return iterable

def dump_json(obj: Any, path: Union[str, Path]) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def append_jsonl(path: Union[str, Path], record: Dict[str, Any]) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
