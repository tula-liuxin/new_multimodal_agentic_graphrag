# -*- coding: utf-8 -*-
from __future__ import annotations
import json, re, os
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Tuple
from .utils import load_cfg, get_logger, ensure_dir, norm_win_abs, tqdm_wrap, sha1

MD_LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")
WIN_PATH = re.compile(r"[A-Za-z]:\\\\[^\n\r\t]+")

def _canon(p: str) -> str:
    p = p.strip().strip('"').strip("'")
    p = p.replace("/", "\\")
    if p.startswith("\\?\\"):
        p = p[4:]
    return p

def run_links(cfg=None, logger=None, max_neighbors:int=5):
    cfg = cfg or load_cfg()
    logger = logger or get_logger()
    data_dir = Path(cfg["data_dir"])
    chunks_path = data_dir / "chunks.jsonl"
    if not chunks_path.exists():
        logger.warning("未发现 %s，跳过 links。", chunks_path)
        return

    rid2path: Dict[str,str] = {}
    path2rid: Dict[str,str] = {}
    texts: Dict[str,str] = {}
    with chunks_path.open("r", encoding="utf-8") as f:
        for line in f:
            try:
                obj = json.loads(line)
            except Exception:
                continue
            rid = obj.get("id") or obj.get("rid") or sha1(obj.get("path",""))
            path = _canon(obj.get("path",""))
            rid2path[rid] = path
            path2rid[path] = rid
            texts[rid] = obj.get("text","")

    edges: List[Tuple[str,str,str]] = []  # (src, dst, type)
    neigh = defaultdict(set)

    for rid, txt in tqdm_wrap(texts.items(), desc="links"):
        for _, link in re.findall(MD_LINK, txt or ""):
            lp = _canon(link)
            if lp in path2rid:
                dst = path2rid[lp]
                edges.append((rid, dst, "md"))
                neigh[rid].add(dst)
        for m in re.findall(WIN_PATH, txt or ""):
            lp = _canon(m)
            if lp in path2rid:
                dst = path2rid[lp]
                edges.append((rid, dst, "path"))
                neigh[rid].add(dst)
        p = Path(rid2path.get(rid,""))
        if p.exists():
            folder = p.parent
            count = 0
            for sib in folder.glob("*.*"):
                sp = _canon(str(sib))
                if sp == str(p): 
                    continue
                if sp in path2rid:
                    neigh[rid].add(path2rid[sp])
                    count += 1
                    if count >= max_neighbors: 
                        break

    ensure_dir(data_dir)
    with (data_dir / "links.jsonl").open("w", encoding="utf-8") as f:
        for s,d,t in edges:
            f.write(json.dumps({"src": s, "dst": d, "type": t}, ensure_ascii=False) + "\n")
    with (data_dir / "link_neighbors.json").open("w", encoding="utf-8") as f:
        json.dump({k:list(v) for k,v in neigh.items()}, f, ensure_ascii=False, indent=2)

    logger.info("links 完成：edges=%d, nodes=%d", len(edges), len(neigh))
