
import os, io, re, json, math, warnings, sys
from bs4 import BeautifulSoup
from pdfminer.high_level import extract_text as pdf_extract
from pypdf import PdfReader
from PIL import Image, ImageOps
import numpy as np
import pytesseract

def _is_windows() -> bool:
    return os.name == "nt"

def _longpath(p: str) -> str:
    """Return a Windows long-path-prefixed absolute path when needed."""
    if not _is_windows():
        return p
    # Normalize to absolute with backslashes
    p = os.path.abspath(p)
    p = p.replace("/", "\\")
    # Already long-path?
    if p.startswith("\\\\?\\"):
        return p
    # UNC path (\\server\share) -> \\?\UNC\server\share\...
    if p.startswith("\\\\"):
        lp = "\\\\?\\UNC" + p[1:]
        return lp
    # Drive path -> \\?\C:\...
    if len(p) >= 3 and p[1] == ":" and p[2] == "\\":
        # Prefer prefix only when length is long to avoid breaking tools,
        # but it's safe to always prefix too.
        if len(p) >= 240:
            return "\\\\?\\" + p
        return p
    return p

# --- HTML / 文本 ---
def read_text_fallback(path: str) -> str:
    lp = _longpath(path)
    with open(lp, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def read_text_auto(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext in [".md", ".markdown", ".txt", ".rst", ".tex", ".csv", ".tsv", ".json", ".yaml", ".yml", ".ini", ".log", ".xml"]:
        return read_text_fallback(path)
    if ext in [".html", ".htm"]:
        lp = _longpath(path)
        with open(lp, "r", encoding="utf-8", errors="ignore") as f:
            soup = BeautifulSoup(f.read(), "lxml")
            return soup.get_text("\n", strip=True)
    if ext in [".pdf"]:
        lp = _longpath(path)
        try:
            return pdf_extract(lp)
        except Exception:
            try:
                reader = PdfReader(lp)
                return "\n".join([p.extract_text() or "" for p in reader.pages])
            except Exception:
                return ""
    if ext in [".xlsx", ".xls", ".docx", ".pptx"]:
        try:
            return read_text_fallback(path)
        except Exception:
            return ""
    return ""

# --- OCR 工具函数 ---
def _downscale_pil(img: Image.Image, max_pixels: int = 2_000_000) -> Image.Image:
    # 将图像面积限制在 max_pixels 以内，加速 OCR
    w, h = img.size
    area = w * h
    if area <= max_pixels or max_pixels <= 0:
        return img
    scale = math.sqrt(max_pixels / float(area))
    new_w = max(1, int(w * scale))
    new_h = max(1, int(h * scale))
    return img.resize((new_w, new_h))

def _pil_open_long(path: str) -> Image.Image:
    lp = _longpath(path)
    return Image.open(lp)

def ocr_image_pytesseract(img_path: str, lang: str = "chi_sim+eng", psm: int = 6) -> str:
    cfg = f"-l {lang} --psm {psm}"
    try:
        with _pil_open_long(img_path) as im:
            im = ImageOps.exif_transpose(im).convert("RGB")
            max_pixels = int(os.getenv("MAX_OCR_PIXELS", "2000000"))
            im = _downscale_pil(im, max_pixels)
            return pytesseract.image_to_string(im, config=cfg)
    except Exception:
        return ""

# EasyOCR Reader 单例缓存（避免每次初始化下载/建模，巨慢）
_EASYOCR_CACHE = {}

def _get_easyocr_reader(langs=("ch_sim","en"), gpu=None):
    """
    返回（并缓存）EasyOCR Reader。
    - 默认 gpu=None -> 自动：CUDA 可用则 True，否则 False。
    - 第一次调用会触发模型下载（官方说明：首次会下载权重，之后走本地缓存）。
    """
    key = (tuple(langs), gpu)
    if key in _EASYOCR_CACHE:
        return _EASYOCR_CACHE[key]
    try:
        import easyocr, torch
        if gpu is None:
            gpu = bool(torch.cuda.is_available())
        # 允许用户通过环境变量指定本地权重目录并禁用下载
        model_dir = os.getenv("EASYOCR_MODEL_DIR", "").strip() or None
        download_enabled = (os.getenv("EASYOCR_DOWNLOAD", "1").strip() not in ["0","false","False"])
        reader = easyocr.Reader(list(langs), gpu=gpu,
                                model_storage_directory=model_dir,
                                download_enabled=download_enabled)
        _EASYOCR_CACHE[key] = reader
        return reader
    except Exception as e:
        _EASYOCR_CACHE[key] = None
        return None

def ocr_image_easyocr(img_path: str, langs = ("ch_sim","en"), gpu=None) -> str:
    """
    用 PIL 打开图像 -> numpy 数组传给 EasyOCR，绕开 OpenCV 对奇怪/超长/Unicode 路径的坑。
    """
    reader = _get_easyocr_reader(langs=langs, gpu=gpu)
    if reader is None:
        return ""
    try:
        with _pil_open_long(img_path) as im:
            im = ImageOps.exif_transpose(im).convert("RGB")
            max_pixels = int(os.getenv("MAX_OCR_PIXELS", "2000000"))
            im = _downscale_pil(im, max_pixels)
            arr = np.array(im)  # HWC, RGB
            res = reader.readtext(arr, detail=0)
            return "\n".join([str(r).strip() for r in res if str(r).strip()])
    except Exception:
        return ""

def ocr_image_auto(img_path: str, lang_tess: str = "chi_sim+eng", psm: int = 6) -> str:
    """
    策略：先 Tesseract，若结果短/空则回退 EasyOCR。
    - EasyOCR 默认启用 GPU（若可用）。如需强制 CPU：设置环境变量 EASYOCR_GPU=0
    - 可通过 EASYOCR_MODEL_DIR 指向本地模型目录，并将 EASYOCR_DOWNLOAD=0 来避免联网下载。
    """
    txt = ocr_image_pytesseract(img_path, lang=lang_tess, psm=psm)
    if txt and len(txt.strip()) >= 2:
        return txt
    gpu_env = os.getenv("EASYOCR_GPU", None)
    gpu_flag = None
    if gpu_env is not None:
        gpu_flag = (str(gpu_env).strip() not in ["0","false","False"])
    txt2 = ocr_image_easyocr(img_path, langs=("ch_sim","en"), gpu=gpu_flag)
    return txt2 or ""

# 兼容旧版（ingest.py 还在导入 ocr_image）
def ocr_image(img_path: str, lang: str = "chi_sim+eng", psm: int = 6) -> str:
    return ocr_image_auto(img_path, lang_tess=lang, psm=psm)

# --- 链接抽取 ---
def extract_html_links(text: str):
    links = re.findall(r'\[([^\]]+)\]\(([^)]+)\)', text)
    return [{"text": t, "href": h} for t, h in links]
