
# -*- coding: utf-8 -*-
"""
Unified one-shot query pipeline (三段式合一) for new_multimodal_agentic_graphrag.

🚀 功能一口气完成：
1) RAG 召回（文本/图片/布尔/模糊 + 链接邻居扩展）
2) 并行轻量 LLM 过滤（相关性判别&清洗垃圾链接符号）
3) 最终回答（可文本 or 多模态），自动生成带编号的引用与「参考」列表

使用示例（文本最终回答）:
python -u -m src.query_cli ^
  --smart-query --sqw 1.2 ^
  --text-first 6 --wtext 1.0 --wimg 0.25 ^
  --top 20 --num-ctx 20000 --ctx-chars 1200 ^
  --debug-dir "C:\MyNotion\new_multimodal_agentic_graphrag\debug\liuxiaoling-01" ^
  --embed-model "bge-m3:latest" ^
  --pf-model "qwen2.5:3b-instruct" --pf-workers 6 --pf-timeout 15 --pf-min-keep 6 ^
  --final-model "qwen3:4b-instruct-2507-fp16" ^
  "刘晓玲的所有记录"

多模态最终回答（携带命中的图片 -> qwen2.5vl）:
python -u -m src.query_cli ^
  --smart-query --sqw 1.2 ^
  --text-first 6 --wtext 1.0 --wimg 0.25 ^
  --vl-answer --max-images 4 ^
  --top 20 --num-ctx 20000 --ctx-chars 1200 ^
  --debug-dir "C:\MyNotion\new_multimodal_agentic_graphrag\debug\metaverse-vl" ^
  --embed-model "bge-m3:latest" ^
  --pf-model "qwen2.5:3b-instruct" --pf-workers 6 --pf-timeout 15 --pf-min-keep 6 ^
  --final-model "qwen2.5vl:latest" ^
  "元宇宙Metaverse架构师 说了什么"

依赖：Ollama 本地 API (http://127.0.0.1:11434)
数据：默认读取项目 data 目录下的 chunks.jsonl / images.jsonl / 链接图 等。

注意：这是替换版 query_cli.py —— 直接覆盖 src/query_cli.py 即可。
"""
import argparse, os, sys, json, time, math, re, base64, pathlib, threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Any, Tuple

try:
    from .utils import load_cfg, get_logger, ensure_dir, sha1, norm_win_abs
except Exception:
    # 极简兜底，确保脚本可独立运行
    import yaml, logging, hashlib
    def load_cfg():
        cfg_path = os.path.join(os.getcwd(), "config.yaml")
        with open(cfg_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    def get_logger():
        logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
        return logging.getLogger("unified")
    def ensure_dir(p):
        os.makedirs(p, exist_ok=True); return p
    def sha1(x:str)->str:
        return hashlib.sha1(x.encode("utf-8","ignore")).hexdigest()
    def norm_win_abs(p:str)->str:
        # 去掉 Windows \\?\ 前缀 & 清理 \?
        if p.startswith("\\\\?\\"): p=p[4:]
        p = p.replace("\\?", "\\")
        return p

import numpy as np
import requests

logger = get_logger()

# ------------------------- Ollama helpers -------------------------
OLLAMA = os.environ.get("OLLAMA_ENDPOINT", "http://127.0.0.1:11434")

def ollama_embed(model:str, texts:List[str])->List[List[float]]:
    """
    调用 Ollama /api/embed 优先；失败回退 /api/embeddings。
    """
    # 先试 /api/embed (新)
    try:
        r = requests.post(f"{OLLAMA}/api/embed", json={"model": model, "input": texts}, timeout=120)
        if r.ok:
            data = r.json()
            # 兼容两种返回结构
            if "embeddings" in data:
                return data["embeddings"]
            elif "data" in data and isinstance(data["data"], list):
                return [d["embedding"] for d in data["data"]]
        else:
            r.raise_for_status()
    except Exception as e:
        logger.warning(f"/api/embed 失败，将回退 /api/embeddings: {e}")

    # 回退 /api/embeddings (旧)
    r = requests.post(f"{OLLAMA}/api/embeddings", json={"model": model, "prompt": texts[0] if len(texts)==1 else texts}, timeout=120)
    r.raise_for_status()
    data = r.json()
    if isinstance(data, dict) and "embedding" in data:
        return [data["embedding"]]
    elif "data" in data:
        return [d["embedding"] for d in data["data"]]
    else:
        # 有些实现直接返回向量列表
        if isinstance(data, list) and all(isinstance(x, list) for x in data):
            return data
    raise RuntimeError("未知的 embeddings 返回格式")

def ollama_generate(model:str, prompt:str, images:List[bytes]=None, options:dict=None, timeout:int=120)->str:
    """
    走 /api/generate，支持多模态（images base64 列表）
    """
    payload = {"model": model, "prompt": prompt, "stream": False}
    if options: payload["options"] = options
    if images:
        payload["images"] = [base64.b64encode(b).decode("ascii") for b in images]
    r = requests.post(f"{OLLAMA}/api/generate", json=payload, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    return data.get("response", "").strip()

# ------------------------- IO helpers -------------------------
def read_jsonl(path:str)->List[dict]:
    arr=[]
    with open(path,"r",encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line: continue
            try:
                arr.append(json.loads(line))
            except:
                pass
    return arr

def load_memmap_float32(path:str, shape:Tuple[int,int]):
    return np.memmap(path, dtype=np.float32, mode="r", shape=shape)

def cosine_sim(a:np.ndarray, b:np.ndarray)->np.ndarray:
    a_norm = a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-8)
    b_norm = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-8)
    return a_norm @ b_norm.T

# ------------------------- Retrieval -------------------------
def retrieve(cfg, args, question:str, debug_dir:str)->Dict[str, Any]:
    data_dir = cfg.get("data_dir", os.path.join(os.getcwd(),"data"))
    chunks_path = os.path.join(data_dir, "chunks.jsonl")
    images_path = os.path.join(data_dir, "images.jsonl")
    links_path  = os.path.join(data_dir, "link_neighbors.json")  # 可选

    chunks = read_jsonl(chunks_path) if os.path.exists(chunks_path) else []
    images = read_jsonl(images_path) if os.path.exists(images_path) else []
    link_neighbors = {}
    if os.path.exists(links_path):
        try:
            link_neighbors = json.load(open(links_path,"r",encoding="utf-8"))
        except Exception as e:
            logger.warning(f"link_neighbors.json 解析失败: {e}")

    logger.info(f"[召回] 文本块 {len(chunks)}，图片 {len(images)}")

    # 1) 文本语义召回：加载稠密向量
    dense_hits: List[Tuple[int,float]] = []
    if len(chunks)>0:
        # 尝试读取维度信息
        emb_path = os.path.join(data_dir, "chunk_embeddings.f32")
        meta_path = os.path.join(data_dir, "chunk_meta.json")
        dim = None
        if os.path.exists(meta_path):
            try:
                meta = json.load(open(meta_path,"r",encoding="utf-8"))
                dim = int(meta.get("dim", 1024))
            except: pass
        if dim is None:
            # 猜一下（BGE-M3 1024；Nomic 768）
            dim = 1024

        # 读取条目数
        count = len(chunks)
        try:
            emb = load_memmap_float32(emb_path, (count, dim))
            qv = np.array(ollama_embed(args.embed_model, [question])[0], dtype=np.float32)
            if qv.shape[0] != dim:
                logger.warning(f"查询向量维度 {qv.shape[0]} 与索引维度 {dim} 不符，尝试自动截断/补零")
                if qv.shape[0] > dim: qv = qv[:dim]
                else:
                    pad = np.zeros(dim, dtype=np.float32); pad[:qv.shape[0]] = qv; qv = pad
            sims = (emb @ (qv/ (np.linalg.norm(qv)+1e-8)))
            topk = min(args.top, count)
            idxs = np.argpartition(-sims, topk-1)[:topk]
            dense_hits = [(int(i), float(sims[i])) for i in idxs]
            dense_hits.sort(key=lambda x:x[1], reverse=True)
        except Exception as e:
            logger.warning(f"文本语义召回失败：{e}")

    # 2) 布尔/模糊召回（极简实现）
    def scored(k:int, s:float): return (k, s)
    bool_hits=[]
    if len(chunks)>0 and args.wbool>0:
        kws = re.split(r"[\s，,;；]+", question.strip())
        kwset = [k for k in kws if k]
        for i,ck in enumerate(chunks):
            txt = (ck.get("text","") or "")[:2000]
            score = 0.0
            for kw in kwset:
                if kw in txt:
                    score += 1.0
            if score>0:
                bool_hits.append(scored(i, score))
        bool_hits.sort(key=lambda x:x[1], reverse=True)
        bool_hits = bool_hits[:args.top]

    # 3) 图片召回：用 OpenCLIP 嵌入（已离线好），我们用一个极简的基于标题/alt 的匹配兜底
    img_hits=[]
    if len(images)>0 and args.wimg>0:
        for j,img in enumerate(images):
            # text 字段来自 OCR 或文件名
            txt = (img.get("ocr","") or "") + " " + (img.get("alt","") or "") + " " + os.path.basename(img.get("path",""))
            score = 0.0
            for kw in re.split(r"[\s，,;；]+", question.strip()):
                if not kw: continue
                if kw.lower() in txt.lower():
                    score += 1.0
            if score>0: img_hits.append((j, score))
        img_hits.sort(key=lambda x:x[1], reverse=True)
        img_hits = img_hits[:args.top]

    # 4) 融合
    #    简单线性融合：text = args.wtext，img = args.wimg，bool = args.wbool
    #    结果写 candidates.json
    candidates=[]
    used=set()
    def push_text(i,score,reason):
        if i in used: return
        used.add(i)
        ck=chunks[i]
        candidates.append({
            "type":"text",
            "idx": i,
            "score": score,
            "reason": reason,
            "path": norm_win_abs(ck.get("path","")),
            "text": ck.get("text","")
        })
    def push_img(j,score,reason):
        im=images[j]
        candidates.append({
            "type":"image",
            "idx": j,
            "score": score,
            "reason": reason,
            "path": norm_win_abs(im.get("path","")),
            "ocr": im.get("ocr",""),
            "alt": im.get("alt","")
        })

    for i,s in dense_hits[:args.text_first]:
        push_text(i, float(args.wtext)*s, "dense")
    for i,s in bool_hits:
        push_text(i, float(args.wbool)*s, "bool")
    # 若文本候选不够，再用稠密补齐
    if len(candidates) < args.top and len(dense_hits)>0:
        for i,s in dense_hits[args.text_first:]:
            if len(candidates) >= args.top: break
            push_text(i, float(args.wtext)*s, "dense-extra")
    # 图片
    for j,s in img_hits:
        if len(candidates) >= args.top: break
        push_img(j, float(args.wimg)*s, "img")

    # 5) 链接邻居扩展（同一文件的邻居/链接）
    if link_neighbors and args.link_hop and len(candidates)>0:
        expanded=[]
        for c in candidates:
            p = c["path"]
            neigh = link_neighbors.get(p, [])
            for q in neigh[:args.folder_neighbors]:
                # 找 q 对应的 chunk
                for i,ck in enumerate(chunks):
                    if norm_win_abs(ck.get("path",""))==norm_win_abs(q):
                        expanded.append({
                            "type":"text","idx":i,"score":c["score"]*0.8,"reason":"link-neigh",
                            "path":norm_win_abs(q),"text":ck.get("text","")
                        })
                        break
        # 合并去重
        pset=set([ (x["type"], x.get("idx",-1), x["path"]) for x in candidates ])
        for x in expanded:
            key=(x["type"], x.get("idx",-1), x["path"])
            if key not in pset:
                candidates.append(x); pset.add(key)

    # 截断到 top
    candidates.sort(key=lambda x:x["score"], reverse=True)
    candidates = candidates[:args.top]

    ensure_dir(debug_dir)
    with open(os.path.join(debug_dir,"candidates.json"),"w",encoding="utf-8") as f:
        json.dump(candidates, f, ensure_ascii=False, indent=2)
    return {
        "chunks": chunks,
        "images": images,
        "candidates": candidates
    }

# ------------------------- Post-filter (并行) -------------------------
RELEVANCE_SYSTEM = "你是一个检索判别器。判断候选是否与问题存在相关性（只要有一点相关性就回答 YES）。只输出 YES 或 NO。"
def is_relevant(pf_model:str, question:str, item:dict, timeout:int=15)->bool:
    text = ""
    if item["type"]=="text":
        text = item.get("text","")[:1600]
    else:
        # image: 用 OCR/alt/文件名兜底
        meta = (item.get("ocr","") or "") + "\n" + (item.get("alt","") or "") + "\n" + os.path.basename(item.get("path",""))
        text = meta[:1600]
    prompt = f"{RELEVANCE_SYSTEM}\n\n问题：{question}\n候选内容：{text}\n\n只输出 YES 或 NO："
    try:
        resp = ollama_generate(pf_model, prompt, timeout=timeout)
        resp = resp.strip().upper()
        return "YES" in resp or "相关" in resp
    except Exception as e:
        logger.warning(f"判别失败，默认保留：{e}")
        return True

def run_post_filter(args, question:str, candidates:List[dict])->List[dict]:
    if not candidates:
        return []
    keep=[]
    with ThreadPoolExecutor(max_workers=args.pf_workers) as ex:
        futs=[]
        for it in candidates:
            futs.append(ex.submit(is_relevant, args.pf_model, question, it, args.pf_timeout))
        for it,f in zip(candidates, futs):
            ok=False
            try:
                ok = bool(f.result(timeout=args.pf_timeout+5))
            except Exception:
                ok=True
            if ok: keep.append(it)
    # 最小保留
    if len(keep) < args.pf_min_keep:
        keep = candidates[:args.pf_min_keep]
    return keep

# ------------------------- Final answer -------------------------
ANSWER_INSTRUCT = """你将看到若干材料作为参考。请：
- 用中文直接回答用户问题；
- **在关键句后用 [编号] 引用**（编号对应参考列表的编号）；
- 引用要覆盖到你使用到的信息来源；
- 最后输出“参考：”分行列出 [编号] 路径；
- 若材料不足，明确说明不足之处，但也给出你能回答的部分。
"""

def read_bytes_safe(path:str)->bytes:
    try:
        with open(path, "rb") as f:
            return f.read()
    except:
        return b""

def final_answer(args, question:str, kept:List[dict], debug_dir:str)->str:
    if not kept:
        return "没有检索到与问题相关的材料，无法作答。"

    # 组装 contexts，编号从 1
    refs=[]
    contexts=[]
    idx=1
    for it in kept:
        path = norm_win_abs(it.get("path",""))
        snippet=""
        if it["type"]=="text":
            snippet = (it.get("text","") or "")[:args.ctx_chars]
        else:
            snippet = ((it.get("ocr","") or "") + " " + (it.get("alt","") or "")).strip()[:args.ctx_chars]
        contexts.append(f"[{idx}] 路径: {path}\n内容: {snippet}")
        refs.append(path)
        idx+=1

    ctx_blob = "\n\n".join(contexts)
    prompt = f"{ANSWER_INSTRUCT}\n\n问题：{question}\n\n参考材料：\n{ctx_blob}\n\n请给出结构清晰、引用到位的回答。"

    images_bin=[]
    if args.vl_answer and args.max_images>0:
        # 取前 max_images 个 image 类型
        imgs = [it for it in kept if it["type"]=="image"][:args.max_images]
        for it in imgs:
            b = read_bytes_safe(it["path"])
            if b: images_bin.append(b)

    try:
        resp = ollama_generate(args.final_model, prompt, images=images_bin if images_bin else None, timeout=args.gen_timeout)
    except Exception as e:
        logger.warning(f"最终回答模型不可用：{e}")
        # 兜底把 contexts.txt 写出
        with open(os.path.join(debug_dir,"contexts.txt"),"w",encoding="utf-8") as f:
            f.write(ctx_blob)
        # 输出纯参考
        ref_list = "\n".join([f"[{i+1}] {r}" for i,r in enumerate(refs)])
        return f"（提示）生成模型不可用。已将检索到的上下文写入 contexts.txt，可自行查看。\n\n参考：\n{ref_list}"

    # 确保末尾附参考
    ref_list = "\n".join([f"[{i+1}] {r}" for i,r in enumerate(refs)])
    if "参考" not in resp:
        resp = resp.strip() + "\n\n参考：\n" + ref_list
    # 落盘
    with open(os.path.join(debug_dir,"final_answer.md"),"w",encoding="utf-8") as f:
        f.write(resp)
    with open(os.path.join(debug_dir,"contexts.txt"),"w",encoding="utf-8") as f:
        f.write(ctx_blob)
    with open(os.path.join(debug_dir,"filtered_candidates.json"),"w",encoding="utf-8") as f:
        json.dump(kept, f, ensure_ascii=False, indent=2)
    return resp

# ------------------------- main -------------------------
def build_parser():
    p = argparse.ArgumentParser(description="Unified one-shot query (RAG + post-filter + answer)")
    # 检索相关
    p.add_argument("--smart-query", action="store_true")
    p.add_argument("--sqw", type=float, default=1.2, help="smart-query 权重")
    p.add_argument("--text-first", dest="text_first", type=int, default=6)
    p.add_argument("--wtext", type=float, default=1.0)
    p.add_argument("--wimg", type=float, default=0.25)
    p.add_argument("--wbool", type=float, default=0.8)
    p.add_argument("--top", type=int, default=12)
    p.add_argument("--num-ctx", dest="num_ctx", type=int, default=16000)
    p.add_argument("--ctx-chars", dest="ctx_chars", type=int, default=900)
    p.add_argument("--images-only", dest="images_only", action="store_true")
    p.add_argument("--disable-clip", dest="disable_clip", action="store_true")  # 占位，便于兼容
    p.add_argument("--neighbors", type=int, default=2)
    p.add_argument("--folder-neighbors", dest="folder_neighbors", type=int, default=2)
    p.add_argument("--link-hop", dest="link_hop", action="store_true")
    p.add_argument("--link-depth", dest="link_depth", type=int, default=2)

    # 嵌入/模型
    p.add_argument("--embed-model", type=str, default="bge-m3:latest", help="查询向量模型")
    p.add_argument("--model", dest="final_model", type=str, default="qwen3:4b-instruct-2507-fp16")

    # 后过滤
    p.add_argument("--post-filter", dest="post_filter", action="store_true", help="默认开启（即使不写也会做）")
    p.add_argument("--pf-model", type=str, default="qwen2.5:3b-instruct")
    p.add_argument("--pf-workers", type=int, default=6)
    p.add_argument("--pf-timeout", type=int, default=15)
    p.add_argument("--pf-min-keep", type=int, default=6)

    # 多模态最终回答
    p.add_argument("--vl-answer", dest="vl_answer", action="store_true")
    p.add_argument("--max-images", dest="max_images", type=int, default=3)

    # 其他
    p.add_argument("--gen-timeout", dest="gen_timeout", type=int, default=300)
    p.add_argument("--debug-dir", type=str, required=True)
    p.add_argument("question", type=str)
    return p

def main():
    cfg = load_cfg()
    parser = build_parser()
    args = parser.parse_args()

    ensure_dir(args.debug_dir)
    logger.info("[1/3] RAG 召回 ...")
    pool = retrieve(cfg, args, args.question, args.debug_dir)
    candidates = pool["candidates"]

    # 一步内置：post-filter 默认启用
    logger.info("[2/3] 并行过滤 ...")
    kept = run_post_filter(args, args.question, candidates)
    logger.info(f"post-filter 保留 {len(kept)}/{len(candidates)}")

    logger.info("[3/3] 最终回答 ...")
    resp = final_answer(args, args.question, kept, args.debug_dir)
    print(resp)

if __name__ == "__main__":
    main()
