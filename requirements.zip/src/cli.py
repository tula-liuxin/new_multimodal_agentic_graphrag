# -*- coding: utf-8 -*-
"""
Thin task runner so you can `python -m src.cli <task>`
Tasks supported: ingest | embed | imgindex | charindex | links | graph
"""
from __future__ import annotations
import sys
from .utils import load_cfg, get_logger

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python -m src.cli [ingest|embed|imgindex|charindex|links|graph]")
        sys.exit(1)
    task = sys.argv[1].lower()
    cfg = load_cfg()
    logger = get_logger(level=cfg.get("log_level", "INFO"))
    logger.info(f"Running task: {task}")
    if task == "ingest":
        from .ingest import run_ingest
        run_ingest(cfg, logger)
    elif task == "embed":
        from .embed_index import run_embed
        run_embed(cfg, logger)
    elif task == "imgindex":
        from .image_encoder import run_imgindex
        run_imgindex(cfg, logger)
    elif task == "charindex":
        from .char_index import run_charindex
        run_charindex(cfg, logger)
    elif task == "links":
        from .link_graph import run_links
        run_links(cfg, logger)
    elif task == "graph":
        from .kg import run_graph
        run_graph(cfg, logger)
    else:
        logger.error(f"Unknown task: {task}")
        sys.exit(2)

if __name__ == "__main__":
    main()
