
import base64, json, time
import requests

class OllamaClient:
    def __init__(self, base_url: str, timeout: int = 120, keep_alive: str = "10m"):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.timeout = timeout
        self.keep_alive = keep_alive
        self.session.headers.update({"Content-Type": "application/json"})

    def _post(self, path, payload):
        url = f"{self.base_url}{path}"
        r = self.session.post(url, data=json.dumps(payload), timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    def embeddings(self, model: str, texts):
        """
        批量嵌入：优先 /api/embed（input 支持 list），失败回退 /api/embeddings（逐条）。
        """
        try:
            payload = {"model": model, "input": texts, "keep_alive": self.keep_alive}
            j = self._post("/api/embed", payload)
            # /api/embed 返回 {"embeddings":[[...],[...]]}
            if "embeddings" in j:
                return j["embeddings"]
        except Exception:
            # 回退到老接口：一次一条
            pass
        out = []
        for t in texts:
            payload = {"model": model, "prompt": t, "keep_alive": self.keep_alive}
            j = self._post("/api/embeddings", payload)
            out.append(j["embedding"])
        return out

    def generate(self, model: str, prompt: str, temperature: float = 0.2, system: str = None, images=None):
        """
        生成（支持多模态）：
        - images: 可为绝对路径列表或 base64 列表（自动识别）。
        - 依赖 Ollama 对多模态模型（如 qwen2.5vl/llava）的 images 字段支持。
        """
        imgs_b64 = []
        if images:
            for p in images:
                if isinstance(p, str) and p and all(c in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\n" for c in p[:20]):
                    # 可能已是 base64
                    imgs_b64.append(p)
                else:
                    with open(p, "rb") as f:
                        imgs_b64.append(base64.b64encode(f.read()).decode("ascii"))
        payload = {
            "model": model,
            "prompt": prompt,
            "options": {"temperature": temperature},
            "keep_alive": self.keep_alive
        }
        if system:
            payload["system"] = system
        if imgs_b64:
            payload["images"] = imgs_b64
        j = self._post("/api/generate", payload)
        # 流式时可能是多段，这里按最终 text 返回
        return j.get("response") or j.get("text") or ""
